# lab3-multipage
lab3
Malichi Dennis 2021384811
Mwiza marie mfuni 2020060221
# Lab 3 - MultiPage Website

This project includes a multi-page website with Home, Services, and Contact pages. It follows modern web development best practices using HTML, CSS Flexbox, and CSS Grid.

## Features
- Responsive navigation bar
- Flexbox layout for the home page
- CSS Grid for services section
- HTML5 contact form with validation
- Responsive design with media queries
